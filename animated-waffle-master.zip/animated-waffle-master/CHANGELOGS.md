# Version 2.3
- Fix unable to record received sms on android 7

# Version 2.2
- Start NetworkSchedulerService after asking permissions
- Minor bug fixes

# Version 2.1
- Force sync and Open adobot using SMS Broadcast receiver instead of content observer

# Version 2.0
- Minimum SDK supported is 21 (Lollipop).
- Using JobScheduler to sync data to server.
- Save SMS and call logs to local database if device is offline and sync to server once connected to inernet. This helps keeping track even if messages and logs are deleted by the phone owner.
- Remove SMS Forwarder feature

# Version 1.1
- First release


